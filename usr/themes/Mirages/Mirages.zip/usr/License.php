<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * License.php
 * Author     : Hran
 * Date       : 2021/02/16
 * Version    :
 * Description:
 */
class License {
    static $name = "Mirages";
    static $pk = "MFJlR1RkWDoxNjEzNDgyMTQ4OjZiZTQ3NmFjYjY4YTQ3NzRkYWM2MTY2OTk1NjI0MjQ30";
}
